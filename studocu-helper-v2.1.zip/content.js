// Content script - Studocu Helper v2.1

// Dọn dẹp bộ nhớ tạm theo dõi lượt xem trên máy khách
(function clearClientStorage() {
  try {
    sessionStorage.clear();
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (key && (key.includes('view') || key.includes('guest') || key.includes('paywall') || key.includes('tracking'))) {
        localStorage.removeItem(key);
      }
    }
  } catch (e) {}
})();

// Tạo giao diện bảng điều khiển
function createFloatingPanel() {
  if (document.getElementById('studocu-helper-panel')) return;

  const panel = document.createElement('div');
  panel.id = 'studocu-helper-panel';
  panel.className = 'studocu-panel-minimized';
  panel.innerHTML = `
    <div class="studocu-panel-header">
      <div class="studocu-panel-logo">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
          <polyline points="14 2 14 8 20 8"/>
        </svg>
        <span>Studocu Helper</span>
      </div>
      <div class="studocu-panel-actions">
        <span class="studocu-panel-version">v2.1</span>
        <button id="studocu-close-btn" class="studocu-panel-close" title="Đóng bảng">✕</button>
      </div>
    </div>
    
    <div class="studocu-panel-content">
      <button id="studocu-export-btn" class="studocu-btn studocu-btn-primary">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
          <circle cx="12" cy="12" r="3"/>
        </svg>
        <span>Tạo file PDF</span>
      </button>
      
      <button id="studocu-bypass-btn" class="studocu-btn studocu-btn-secondary">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 6h18"/>
          <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
          <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
        </svg>
        <span>Bypass & Tải lại</span>
      </button>
      
      <div id="studocu-status" class="studocu-status-bar">
        <span class="studocu-status-dot"></span>
        <span id="studocu-status-text">Đã mở khóa tài liệu</span>
      </div>
      
      <div class="studocu-panel-footer">
        <a href="https://github.com/ruskicoder" target="_blank" class="studocu-github-link">@ruskicoder</a>
      </div>
    </div>
  `;

  const toggleBtn = document.createElement('button');
  toggleBtn.id = 'studocu-toggle-btn';
  toggleBtn.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
      <polyline points="14 2 14 8 20 8"/>
    </svg>
  `;
  toggleBtn.title = 'Mở / Đóng Studocu Helper';

  document.body.appendChild(panel);
  document.body.appendChild(toggleBtn);

  initEvents(panel, toggleBtn);
}

// Gán sự kiện
function initEvents(panel, toggleBtn) {
  const closeBtn = document.getElementById('studocu-close-btn');
  const exportBtn = document.getElementById('studocu-export-btn');
  const bypassBtn = document.getElementById('studocu-bypass-btn');

  const toggle = () => panel.classList.toggle('studocu-panel-minimized');
  toggleBtn.addEventListener('click', toggle);
  if (closeBtn) closeBtn.addEventListener('click', toggle);

  // Nhận tín hiệu từ toolbar icon
  chrome.runtime.onMessage.addListener((req) => {
    if (req.action === 'togglePanel') toggle();
  });

  // Xuất PDF
  exportBtn.addEventListener('click', async () => {
    exportBtn.disabled = true;
    try {
      await processAndExportPDF();
    } catch (err) {
      updateStatus('Lỗi: ' + err.message, false);
    } finally {
      exportBtn.disabled = false;
    }
  });

  // Bypass thủ công
  bypassBtn.addEventListener('click', async () => {
    bypassBtn.disabled = true;
    updateStatus('Đang xóa cookies...', true);
    try {
      const res = await chrome.runtime.sendMessage({ action: 'clearCookies' });
      if (res?.success) {
        updateStatus(`Đã xóa ${res.count} cookies! Đang tải lại...`, false);
      } else {
        updateStatus('Lỗi: ' + (res?.error || 'Thất bại'), false);
        bypassBtn.disabled = false;
      }
    } catch (e) {
      updateStatus('Lỗi: ' + e.message, false);
      bypassBtn.disabled = false;
    }
  });
}

function updateStatus(message, isProcessing = false) {
  const statusText = document.getElementById('studocu-status-text');
  const statusBar = document.getElementById('studocu-status');
  if (statusText) statusText.textContent = message;
  if (statusBar) {
    statusBar.classList.toggle('studocu-status-processing', isProcessing);
  }
}

// Tự động cuộn để tải các trang chưa render
async function ensureAllPagesLoaded(pages) {
  let unloaded = 0;
  for (const page of pages) {
    if (!page.querySelector('.pc .t') && !page.querySelector('img.bi, .bi img, img[src*="page"]')) {
      unloaded++;
    }
  }
  if (unloaded === 0) return;

  updateStatus(`Đang cuộn tải ${unloaded} trang...`, true);
  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    const hasContent = () => page.querySelector('.pc .t') || page.querySelector('img.bi, .bi img, img[src*="page"]');
    if (!hasContent()) {
      updateStatus(`Đang tải trang ${i + 1}/${pages.length}...`, true);
      page.scrollIntoView({ behavior: 'instant', block: 'center' });
      const start = Date.now();
      while (!hasContent() && (Date.now() - start < 1200)) {
        await new Promise(r => setTimeout(r, 80));
      }
    }
  }
}

const NORMAL_PROPS = [
  'position', 'left', 'top', 'bottom', 'right',
  'font-family', 'font-weight', 'font-style',
  'color', 'background-color',
  'text-align', 'white-space',
  'display', 'visibility', 'opacity', 'z-index',
  'text-shadow', 'unicode-bidi', 'font-feature-settings', 'padding'
];

function copyComputedStyle(source, target, scaleFactor, shouldScaleHeight, shouldScaleWidth, heightDivisor, widthDivisor, shouldScaleMargin) {
  const computed = window.getComputedStyle(source);
  let styleStr = '';

  for (let i = 0; i < NORMAL_PROPS.length; i++) {
    const prop = NORMAL_PROPS[i];
    const val = computed.getPropertyValue(prop);
    if (val && val !== 'none' && val !== 'auto' && val !== 'normal') {
      styleStr += `${prop}: ${val} !important; `;
    }
  }

  const w = computed.getPropertyValue('width');
  if (w && w !== 'none' && w !== 'auto') {
    if (shouldScaleWidth) {
      const num = parseFloat(w);
      if (!isNaN(num) && num > 0) {
        const unit = w.replace(num.toString(), '');
        styleStr += `width: ${num / widthDivisor}${unit} !important; `;
      } else {
        styleStr += `width: ${w} !important; `;
      }
    } else {
      styleStr += `width: ${w} !important; `;
    }
  }

  const h = computed.getPropertyValue('height');
  if (h && h !== 'none' && h !== 'auto') {
    if (shouldScaleHeight) {
      const num = parseFloat(h);
      if (!isNaN(num) && num > 0) {
        const unit = h.replace(num.toString(), '');
        styleStr += `height: ${num / heightDivisor}${unit} !important; `;
      } else {
        styleStr += `height: ${h} !important; `;
      }
    } else {
      styleStr += `height: ${h} !important; `;
    }
  }

  const margins = ['margin-top', 'margin-right', 'margin-bottom', 'margin-left'];
  for (let i = 0; i < margins.length; i++) {
    const prop = margins[i];
    const val = computed.getPropertyValue(prop);
    if (val && val !== 'auto') {
      const num = parseFloat(val);
      if (!isNaN(num)) {
        if (shouldScaleMargin && num !== 0) {
          const unit = val.replace(num.toString(), '');
          styleStr += `${prop}: ${num / scaleFactor}${unit} !important; `;
        } else {
          styleStr += `${prop}: ${val} !important; `;
        }
      }
    }
  }

  const fontProps = ['font-size', 'line-height'];
  for (let i = 0; i < fontProps.length; i++) {
    const prop = fontProps[i];
    const val = computed.getPropertyValue(prop);
    if (val && val !== 'none' && val !== 'auto' && val !== 'normal') {
      const num = parseFloat(val);
      if (!isNaN(num) && num !== 0) {
        const unit = val.replace(num.toString(), '');
        styleStr += `${prop}: ${num / scaleFactor}${unit} !important; `;
      } else {
        styleStr += `${prop}: ${val} !important; `;
      }
    }
  }

  const origin = computed.getPropertyValue('transform-origin');
  if (origin) {
    styleStr += `transform-origin: ${origin} !important; -webkit-transform-origin: ${origin} !important; `;
  }

  styleStr += 'overflow: visible !important; max-width: none !important; max-height: none !important; clip: auto !important; clip-path: none !important; ';
  target.style.cssText += styleStr;
}

function deepCloneWithStyles(element, scaleFactor, heightDivisor) {
  const clone = element.cloneNode(false);
  const classList = element.classList;
  const hasTextClass = classList && classList.contains('t');
  const hasUnderscoreClass = classList && classList.contains('_');
  const shouldScaleMargin = element.tagName === 'SPAN' &&
                            hasUnderscoreClass &&
                            Array.from(classList).some(cls => /^_(?:\d+[a-z]*|[a-z]+\d*)$/i.test(cls));

  copyComputedStyle(element, clone, scaleFactor, hasTextClass, hasUnderscoreClass, heightDivisor, 4, shouldScaleMargin);

  if (classList && classList.contains('pc')) {
    clone.style.setProperty('transform', 'none', 'important');
    clone.style.setProperty('-webkit-transform', 'none', 'important');
    clone.style.setProperty('overflow', 'visible', 'important');
    clone.style.setProperty('max-width', 'none', 'important');
    clone.style.setProperty('max-height', 'none', 'important');
  }

  if (element.childNodes.length === 1 && element.childNodes[0].nodeType === 3) {
    clone.textContent = element.textContent;
  } else {
    for (let i = 0; i < element.childNodes.length; i++) {
      const child = element.childNodes[i];
      if (child.nodeType === 1) {
        clone.appendChild(deepCloneWithStyles(child, scaleFactor, heightDivisor));
      } else if (child.nodeType === 3) {
        clone.appendChild(child.cloneNode(true));
      }
    }
  }
  return clone;
}

// Xử lý tạo và xuất PDF
async function processAndExportPDF() {
  const pages = document.querySelectorAll('div[data-page-index], #page-container .pf');
  if (pages.length === 0) {
    alert('⚠️ Không tìm thấy trang tài liệu nào trên trang hiện tại.');
    return;
  }

  // Tự động nạp các trang lazy load nếu có
  await ensureAllPagesLoaded(pages);

  updateStatus('Đang xử lý tài liệu...', true);

  const SCALE_FACTOR = 4;
  const HEIGHT_SCALE_DIVISOR = 4;

  const existing = document.getElementById('clean-viewer-container');
  if (existing) existing.remove();

  const viewerContainer = document.createElement('div');
  viewerContainer.id = 'clean-viewer-container';

  pages.forEach((page, index) => {
    const pc = page.querySelector('.pc');
    let width = 595.3;
    let height = 841.9;

    if (pc) {
      const pcStyle = window.getComputedStyle(pc);
      const pcWidth = parseFloat(pcStyle.width);
      const pcHeight = parseFloat(pcStyle.height);
      if (!isNaN(pcWidth) && pcWidth > 0 && !isNaN(pcHeight) && pcHeight > 0) {
        width = pcWidth;
        height = pcHeight;
      } else {
        const rect = pc.getBoundingClientRect();
        if (rect.width > 10 && rect.height > 10) {
          width = rect.width;
          height = rect.height;
        }
      }
    }

    const newPage = document.createElement('div');
    newPage.className = 'std-page';
    newPage.id = `page-${index + 1}`;
    newPage.style.width = width + 'px';
    newPage.style.height = height + 'px';

    // Layer ảnh nền
    const originalImg = page.querySelector('img.bi, .bi img, .pf > img, img[src*="page"]') || page.querySelector('img');
    if (originalImg) {
      const bgLayer = document.createElement('div');
      bgLayer.className = 'layer-bg';
      const imgClone = originalImg.cloneNode(true);
      imgClone.style.cssText = 'width: 100%; height: 100%; object-fit: cover; object-position: top center;';
      bgLayer.appendChild(imgClone);
      newPage.appendChild(bgLayer);
    }

    // Layer Text
    if (pc) {
      const textLayer = document.createElement('div');
      textLayer.className = 'layer-text';
      const pcClone = deepCloneWithStyles(pc, SCALE_FACTOR, HEIGHT_SCALE_DIVISOR);
      pcClone.querySelectorAll('img').forEach(img => img.style.display = 'none');
      textLayer.appendChild(pcClone);
      newPage.appendChild(textLayer);
    }

    viewerContainer.appendChild(newPage);
  });

  document.body.appendChild(viewerContainer);
  document.body.classList.add('studocu-printing');

  // Khôi phục giao diện gốc sau khi in hoặc hủy in
  window.addEventListener('afterprint', () => {
    const container = document.getElementById('clean-viewer-container');
    if (container) container.remove();
    document.body.classList.remove('studocu-printing');
    updateStatus('Đã sẵn sàng', false);
  }, { once: true });

  updateStatus('Đang mở hộp thoại in...', false);
  setTimeout(() => {
    window.print();
  }, 400);
}

// Khởi chạy khi DOM sẵn sàng
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', createFloatingPanel);
} else {
  createFloatingPanel();
}
